<?php session_start();?>
<?php if(@$_GET['page'] == 'login');?>
<!DOCTYPE html>
<html lang="en">
<?php
if(@$_GET['page'] == 'login');
require_once('include/head.php');
?>
<title>Login</title>
<?php
        include_once('connect.php');  
        if(isset($_POST['submit']))    {
            $username =  ($_POST['email']);
            $password = $conn->real_escape_string ($_POST['phone']);

          $sql = "SELECT * FROM `admin_reg` WHERE `email` = '".$username."' AND `phone` = '".$password."'";
            
            $result = $conn->query($sql);
            
            if($result->num_rows > 0){ 
                $row = $result->fetch_assoc();

                $_SESSION['id_admin'] = $row['id_admin'];
                $_SESSION['email'] = $row['email'];
                $_SESSION['name'] = $row['name'];
                $_SESSION['surname'] = $row['surname'];
                header("location:index_a.php"); 

            }else{
                echo "<script>alert('Username or Password is invalid');window.location='login_a.php'</script>";
            }
        }

        ?> 

</head>
<body>
<div class="container">
       <div class="row">
           <div class="col-md-8 mx-auto mt-5">
               <div class="card">
                    <form method="post" >
                   <div class="card-header text-center">
                       Log in to Your Account!!!
                   </div>
                        <div class="card-body ">
                            <div class="form-group row">
                                <label for="Email" class="col-sm-3 col-form-label">Email</label>
                                <div class="col-sm-9">
                                <input type="text" class="form-control" id="email" name="email" placeholder = "Email ของผู้ใช้งาน">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="IdStudent" class="col-sm-3 col-form-label">Phone</label>
                                <div class="col-sm-9">
                                <input type="phone" class="form-control" id="phone" name="phone" placeholder = "Phone ของผู้ใช้งาน">
                            </div>
                            </div>
                                <div class="card-footer text-center">
                                    <input type="submit" name="submit" class="btn btn-success" value="Login">
               </div>
           </div>
           </form>
       </div>
   </div>
   <?php
if(@$_GET['page'] == 'login');
require_once('include/scr.php');
?>
</body>
    </html>