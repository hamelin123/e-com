<!DOCTYPE html>
<html lang="en">
<?php
if(@$_GET['page'] == 'edit');
require_once('include/head.php');
?>
    <title>Me2</title>
</head>
<body>
<?php
if(@$_GET['page'] == 'edit');
require_once('include/nav.php');
?>
    <h1>แก้ไขบทความ</h1>
    <div class="container-fluid">
            <div class="input-group mb-3">
                <span class="input-group-text" id="inputGroup-sizing-default">หัวข้อบทความ</span>
                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
            </div>
            <div class="card-body">
                <div class="mb-3">
                <textarea name="editor1" id="editor1" rows="10" cols="80">
                เขียนบทความที่ต้องการ
                </textarea>
            </div>
        </div>
            <div class="dropdown mb-3">
                <a for="staticEmail" style="font-style: 10px;" >ประเภทบทความ&nbsp;</a> 
                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false">
                  เลือกประเภท
                </button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
                  <li><button class="dropdown-item" type="button" href="#">1</button></li>
                  <li><button class="dropdown-item" type="button">2</button></li>
                  <li><button class="dropdown-item" type="button">3</button></li>
                </ul>
              </div>
              <div class="input-group mb-3">
                <span class="input-group-text" id="inputGroup-sizing-default">คําค้นหา</span>
                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
            </div>
            <div class="dropdown">
                <a for="staticEmail" style="font-style: 10px;" >สถานะบทความ&nbsp;</a> 
                <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false">
                    เลือกประเภท
                </button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenu2">
                  <li><button class="dropdown-item" type="button" href="#">1</button></li>
                  <li><button class="dropdown-item" type="button">2</button></li>
                  <li><button class="dropdown-item" type="button">3</button></li>
                </ul>
              </div>
              <a type="button" class="btn btn-primary center" href="#">Edit</a>
              <?php
if(@$_GET['page'] == 'index');
require_once('include/scr.php');
?>
    <script>
         $(document).ready(function(){
            $('.dropdown-toggle').dropdown()
        });
    </script>
<!-- CKEditer -->
<script src="//cdn.ckeditor.com/4.16.1/full/ckeditor.js"></script>
<script> CKEDITOR.replace( 'editor1' );</script>
<!-- END CKEditer -->
</body>
</html>