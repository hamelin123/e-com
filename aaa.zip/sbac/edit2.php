<!DOCTYPE html>
<html lang="en">
<?php
if(@$_GET['page'] == 'edit2');
require_once('include/head.php');
?>
    <title>edit2</title>
</head>
<body>
<?php
if(@$_GET['page'] == 'edit2');
require_once('include/nav.php');
?>
    <h1>เพิ่มโครงการและงานวิจัย</h1>
    <div class="container">
            <div class="input-group mb-3">
                <span class="input-group-text" id="inputGroup-sizing-default">เพิ่มโครงการและงานวิจัยชื่องานวิจัยนวัตกรรมหรือโครงการ (ภาษาไทย)</span>
                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
            </div>
            <div class="input-group mb-3">
                <span class="input-group-text" id="inputGroup-sizing-default">เพิ่มโครงการและงานวิจัยชื่องานวิจัยนวัตกรรมหรือโครงการ (ภาษาอังกฤษ)</span>
                <input type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
            </div>
    <h2>ลักษณะโครงการ</h2>
    <div class="container">
    <div class="form-check form-check-inline col-sm-3 mb-3">
        <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
        <label class="form-check-label" for="inlineCheckbox1">โครงการใหม่</label>
      </div>
      <div class="form-check form-check-inline ">
        <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
        <label class="form-check-label" for="inlineCheckbox2">โครงการต่อเนื่อง โปรดระบุรหัส โครงการอ้างอิง</label>
        <input type="text" placeholder="Search..">
        <button type="submit"><i class="fa fa-search"></i></button>
      </div>
    </div>
    <h2>ประเภทกลุ่มโครงการ</h2>
    <div class="container">
        <div class="form-check form-check-inline col-sm-3 mb-3">
            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
            <label class="form-check-label" for="inlineCheckbox1">Small Medium Enterprise: SME</label>
        </div>
        <div class="form-check form-check-inline col-sm-3 mb-3">
            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
            <label class="form-check-label" for="inlineCheckbox1">Startup</label>
          </div>
          <div class="form-check form-check-inline col-sm-3 mb-3">
            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
            <label class="form-check-label" for="inlineCheckbox1">Tech Startup</label>
          </div>
        </div>
        <div class="container">
            <div class="form-check form-check-inline col-sm-3 mb-3">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                <label class="form-check-label" for="inlineCheckbox1">Research</label>
            </div>
            <div class="form-check form-check-inline col-sm-3 mb-3">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                <label class="form-check-label" for="inlineCheckbox1">Research&Development</label>
              </div>
              <div class="form-check form-check-inline col-sm-3 mb-3">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                <label class="form-check-label" for="inlineCheckbox1">ProjectDevelopment</label>
              </div>
            </div>
            <div class="container">
                <div class="form-check form-check-inline col-sm-3 mb-3">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                    <label class="form-check-label" for="inlineCheckbox1">Education</label>
                </div>
            </div>
            <h2>รูปแบบการดําเนินโครงการ</h2>
        <div class="container">
            <div class="form-check form-check-inline col-sm-3 mb-3">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                <label class="form-check-label" for="inlineCheckbox1">แผนธุรกิจ</label>
            </div>
            <div class="form-check form-check-inline col-sm-3 mb-3">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                <label class="form-check-label" for="inlineCheckbox1">แนวความคิด/นโยบายการดําเนินการ</label>
            </div>
            <div class="form-check form-check-inline col-sm-3 mb-3">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                <label class="form-check-label" for="inlineCheckbox1">ชิ้นงาน</label>
            </div>
                    </div>
        <h2>ลักษณะจํานวนผู้ร่วมการศึกษาวิจัยและพัฒนา</h2>
        <div class="container">
            <div class="form-check form-check-inline col-sm-3 mb-3">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                <label class="form-check-label" for="inlineCheckbox1">บุคคล</label>
            </div>
            <div class="form-check form-check-inline col-sm-3 mb-3">
                <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                <label class="form-check-label" for="inlineCheckbox1">แบบทีม</label>
            </div>
        </div>
        <a type="button" class="btn btn-primary center" href="#">Edit</a>
    </div>
    
    <?php
if(@$_GET['page'] == 'edit2');
require_once('include/scr.php');
?>
</body>
</html>