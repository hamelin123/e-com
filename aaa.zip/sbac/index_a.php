<?php session_start();?>
<!doctype html>
<html lang="en">
  <head>
    <?php
    if(@$_GET['page'] == 'index');
    require_once('include/head.php');
    ?>
      <?php
    if(@$_GET['page'] == 'index');
    require_once('connect.php');
    ?>
    <title>Index</title>
    </head>
    
    <body>
      <!--navbar-->

      
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">

    <title>Dashboard Template for Bootstrap</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/dashboard/">

    <!-- Bootstrap core CSS -->
    <link href="../../dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
  </head>

  <body>
  <?php
    if(@$_GET['page'] == 'index');
    require_once('include/nav_a.php');
    ?>
     <?php
    if(@$_GET['page'] == 'index');
    require_once('include/ctn.php');
    ?>


        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">


          <h2>Student List</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm myTable" style="width: 100% " >
              <thead>
                <tr>
                  <th>id_stu</th>
                  <th>name</th>
                  <th>surname</th>
                  <th>department</th>
                  <th>major</th>
                  <th>level</th>
                  <th>level1</th>
                  <th>time</th>
                  <th>email</th>
                  <th>phone</th>
                  <th>line</th>
                  <th>status</th>
                  <th>edit</th>
                  <th>delete</th>
                </tr>
              </thead>
              <tbody>
              <?php $search=isset($_GET['search']) ? $_GET['search']: '';
    
    $sql = "SELECT * FROM student WHERE id_stu LIKE '%".$search."%'"; 
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    ?>
              <?php 
            $num = 0;
            while($row = $result->fetch_assoc() ) { 
              $num++;
              ?>
               <tr>
                  <td><?php echo $row["id_stu"];?></td>
                  <td><?php echo $row["name"];?></td>
                  <td><?php echo $row["surname"];?></td>
                  <td><?php echo $row["department"];?></td>
                  <td><?php echo $row["major"];?></td>
                  <td><?php echo $row["level"];?></td>
                  <td><?php echo $row["level1"];?></td>
                  <td><?php echo $row["time"];?></td>
                  <td><?php echo $row["email"];?></td>
                  <td><?php echo $row["phone"];?></td>
                  <td><?php echo $row["line"];?></td>
                  <td><?php echo $row["status"];?></td>
                  <td>
                  <a href="edit_a.php?id_stu=<?php echo $row['id_stu']; ?>" class="btn btn-sm btn-warning text-white">
                  <span data-feather="edit"></span> edit
                  </a> 
                </td>
                <td>
                  <a href="delete_a.php?id_stu=<?php echo $row['id_stu']; ?>" onclick="deleteItem(<?php echo $row['id_stu']; ?>);" class="btn btn-sm btn-danger">
                  <span data-feather="delete"></span> Delete
                  </a>
                </td>
                </tr>
                <?php } ?>
              </tbody>
              <tfoot>
              <tr>
                  <th>id_stu</th>
                  <th>name</th>
                  <th>surname</th>
                  <th>department</th>
                  <th>major</th>
                  <th>level</th>
                  <th>level1</th>
                  <th>time</th>
                  <th>email</th>
                  <th>phone</th>
                  <th>line</th>
                  <th>status</th>
                  <th>edit</th>
                  <th>delete</th>
                </tr>
              </tfoot>
            </table>
          </div>
        </main>
      </div>
    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <?php
if(@$_GET['page'] == 'me');
require_once('include/scr1.php');
?>
    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    <!-- Graphs -->
    <script>
$(document).ready( function () {
    $('.myTable').DataTable();
} );
    </script>
      <?php
      if(@$_GET['page'] == 'index');
      require_once('include/scr.php');
      ?>
  </body>
</html>
