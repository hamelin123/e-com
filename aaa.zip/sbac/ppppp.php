<!DOCTYPE html>
<html lang="en">
<?php
if(@$_GET['page'] == 'ppppp');
require_once('include/head.php');
?>
    <title>Me</title>
</head>
<body>
<?php
if(@$_GET['page'] == 'ppppp');
require_once('include/nav.php');
?>
<h5 style="text-align:center;">รหัสโครงการ...... ชื่อโครงการ.....</h5>
<h5 style="text-align:right;">ช่วงระยะเวลา......</h5>
<h5 style="text-align:lift;">รายละเอียด</h5>
<a style="text-align:lift;">ชื่อทีม</a>
<a style="text-align:center;">........</a>
<h5 style="text-align:lift;">ข้อมูลที่ปรึกษาโครงการ<หลัก></h5>
<form class="form-inline my-2 my-lg-0">
    <style>
    div {text-align: right;}
    th {text-align: center;}
  </style>
    
    

  </form>
  <table class="table table-bordered ">
    <thead>
      <tr>
        <th scope="col">ลำดับ</th>
        <th scope="col">ชื่อ-นามสกุล</th>
        <th scope="col">ตำแหน่ง</th>
        <th scope="col">ภาควิชา</th>
        <th scope="col">สาขา</th>
        
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">1</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
    </tr>
    <tr>
        <th scope="row">2</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
    </tr>
    <tr>
        <th scope="row">3</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
    </tr>
      
    </tbody>
  </table>
  <h5 style="text-align:lift;">ข้อมูลที่ปรึกษาโครงการ<ร่วม></h5>
  <table class="table table-bordered ">
    <thead>
      <tr>
        <th scope="col">ลำดับ</th>
        <th scope="col">ชื่อ-นามสกุล</th>
        <th scope="col">ตำแหน่ง</th>
        <th scope="col">ภาควิชา</th>
        <th scope="col">สาขา</th>
        
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">1</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
    </tr>
    <tr>
        <th scope="row">2</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
    </tr>
    <tr>
        <th scope="row">3</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
    </tr>
      
    </tbody>
  </table>
  <h5 style="text-align:lift;">สมาชิกผู้ร่วมทีม</h5>
  <table class="table table-bordered ">
    <thead>
      <tr>
        <th scope="col">ลำดับ</th>
        <th scope="col">ชื่อ-นามสกุล</th>
        <th scope="col">ตำแหน่ง</th>
        <th scope="col">ภาควิชา</th>
        <th scope="col">สาขา</th>
        
      </tr>
    </thead>
    <tbody>
      <tr>
        <th scope="row">1</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
    </tr>
    <tr>
        <th scope="row">2</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
    </tr>
    <tr>
        <th scope="row">3</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
    </tr>
    <tr>
        <th scope="row">4</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
    </tr>
    <tr>
        <th scope="row">5</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
    </tr>
    <tr>
        <th scope="row">6</th>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        
    </tr>
      
    </tbody>
  </table>
</div>
<?php
if(@$_GET['page'] == 'ppppp');
require_once('include/scr.php');
?>
</body>
</html>