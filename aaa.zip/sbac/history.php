<?php session_start();?>
<?php 
        include('connect.php');
        $sql = "SELECT * FROM `student` ";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        ?>
<!DOCTYPE html>
<html lang="en">
<?php
if(@$_GET['page'] == 'history');
require_once('include/head.php');
?>
    <title>History</title>
</head>
<body>
<?php
if(@$_GET['page'] == 'history');
require_once('include/nav.php');
?>
    <h1>Profile Detail</h1>
    <h1>My Badges</h1>
    <h1><img src="img/aa.jpeg" alt="Smiley face" width="75" height="75"></h1>
    <div class="container">
        <div class="row">
            <div class="col-2">
                <h1><img src="img/k.png" alt="Smiley face" width="150" height="150"></h1>
            </div>
            <div class="col-5">
                <div class="row">
                    <div class="col">รหัสประจำตัว:  <?php echo $row['id_stu']?> 11111 </div>
                    <div class="col">ชื่อ: <?php echo $row['name']?>game </div>
                    <div class="col">นามสกุล:<?php echo $row['sername']?>true </div>
                </div>
                <div class="row">
                    <div class="col">ภาควิชา:<?php echo $row['department']?> it </div>
                    <div class="col">สาขาวิชา:<?php echo $row['major']?> dev </div>
                </div>
                <div class="row">
                    <div class="col">ระดับการศึกษา: <?php echo $row['level']?>1 / </div>
                    <div class="col">รอบ:<?php echo $row['level1']?> 2</div>
                </div>
                <div class="row">
                    <div class="col">ระดับการศึกษา: <?php echo $row['level']?>1 / </div>
                    <div class="col">รอบ:<?php echo $row['level1']?> 2</div>
                </div>
                <p> ข้อมูลการติดต่อ  </p>
                <div class="col">email:<?php echo $row['email']?> ssa@gmail.com</div>
                <div class="col">เบอร์โทร:<?php echo $row['phone']?> 0818118890</div>
                <div class="col">Line:<?php echo $row['email']?> aasqw</div>
            </div>
        </div>	
    </div>
    <?php
if(@$_GET['page'] == 'history');
require_once('include/scr.php');
?>
</body>
</html>