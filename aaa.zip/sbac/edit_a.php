<?php session_start();?>

<!doctype html>
<html lang="en">
  <head>
    <?php
    if(@$_GET['page'] == 'index');
    require_once('include/head.php');
    ?>
      <?php

    require_once('connect.php');

    ?>

    <title>Index</title>
    </head>
    
    <body>
      <!--navbar-->

      
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">

    <title>Dashboard Template for Bootstrap</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/dashboard/">

    <!-- Bootstrap core CSS -->
    <link href="../../dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="dashboard.css" rel="stylesheet">
  </head>

  <body>
  <?php
    if(@$_GET['page'] == 'index');
    require_once('include/nav_a.php');
    ?>
        <?php
    if(@$_GET['page'] == 'index');
    require_once('include/ctn.php');
    ?>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">

        <?php 
        $id = $_GET['id_stu'];
        $sql = "SELECT * FROM `student` WHERE `id_stu` = '".$id."' ";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();

        ?>
        <section class="content">
      <div class="card card-primary">
        <div class="card-header">
          <h2>Edit Student List</h2>
          <form role="form" action="update_a.php" method="post">
          <div class="card-body">
          <div class="form-group">
              <label for="id_stu">ID Student</label>
              <input type="text" disabled class="form-control" id="id_stu" name="id_stu" placeholder="id_stu" value="<?php echo $row['id_stu'] ?>" required>
            </div>
          <div class="form-group">
              <label for="name">Name</label>
              <input type="text" class="form-control" id="name" name="name" placeholder="Name" value="<?php echo $row['name'] ?>" required>
            </div>
            <div class="form-group">
              <label for="surname">Surname</label>
              <input type="text" class="form-control" id="surname" name="surname" placeholder="surname" value="<?php echo $row['surname'] ?>" required>
            </div>
            <div class="form-group">
              <label for="department">Department</label>
              <input type="text" class="form-control" id="department" name="department" placeholder="department" value="<?php echo $row['department'] ?>" required>
            </div>
            <div class="form-group">
              <label for="major">Major</label>
              <input type="text" class="form-control" id="major" name="major" placeholder="major" value="<?php echo $row['major'] ?>" required>
            </div>
            <div class="form-group">
              <label for="level">Level</label>
              <input type="text" class="form-control" id="level" name="level" placeholder="level" value="<?php echo $row['level'] ?>" required>
            </div>
            <div class="form-group">
              <label for="level1">Level1</label>
              <input type="text" class="form-control" id="level" name="level" placeholder="level1" value="<?php echo $row['level1'] ?>" required>
            </div>
            <div class="form-group">
              <label for="time">Time</label>
              <input type="text" class="form-control" id="time" name="time" placeholder="time" value="<?php echo $row['time'] ?>" required>
            </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input type="text" class="form-control" id="email" name="email" placeholder="email" value="<?php echo $row['email'] ?>" required>
            </div>
            <div class="form-group">
              <label for="phone">Phone</label>
              <input type="text" class="form-control" id="phone" name="phone" placeholder="phone" value="<?php echo $row['phone'] ?>" required>
            </div>
            <div class="form-group">
              <label for="line">Line</label>
              <input type="text" class="form-control" id="line" name="line" placeholder="line" value="<?php echo $row['line'] ?>" required>
            </div>
            <div class="form-group">
              <label for="status">Status</label>
              <input type="text" class="form-control" id="status" name="status" placeholder="status" value="<?php echo $row['status'] ?>" required>
            </div>
            <div class="card-footer">
            <input type="hidden" name="id_stu" value="<?php echo $id;?>">
            <button type="submit" name="submit" class="btn btn-primary">Submit</button>

        </div>
            </form>
      </div>    
    </section>
    
    <!-- /.content -->
  </div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>

    <!-- Graphs -->
    <script>
$(document).ready( function () {
    $('.myTable').DataTable();
} );
    </script>
      <?php
      if(@$_GET['page'] == 'index');
      require_once('include/scr.php');
      ?>
  </body>
</html>
