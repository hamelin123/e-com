<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

   

    include 'connect.php';

    $sql = 'SELECT * FROM radar';
    $result = mysqli_query($conn,$sql);
    
    while($row = mysqli_fetch_array($result,MYSQLI_BOTH)){
        
    }

    //mysqli_query($conn);

    //echo json_encode($radar);


    ?>
<?php session_start();?>
<?php if(@$_GET['page'] == 'Performance');?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/css.css">
    <link rel="stylesheet" href="fonts/thsarabunnew.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
            body
            {  
                font-family: 'THSarabunNew', sans-serif; 
            }
    </style>
<title>Performance</title>

</head>
<body>
    
<div>
  <canvas id="myChart" width="400" height="400"></canvas>
</div>


<script>

    const data = {
  labels: [
    'Communication',
    'Customer Service',
    'Interpersonal',
    'Computer & Technology',
    'Active Listening',
    'Creativity',
    'Leadership',
    'Problem Solving',
    'Time Management',
    'Transferable',
    'Adaptability',
    'Empathy',
    'Integrity',
    'Work Ethic'
  ],
  datasets: [{
    label: 'Soft Skills',
    data: [<?php echo $row['Communication']; ?>, <?php echo $row['Customer_Service']; ?>, <?php echo $row['Interpersonal']; ?>,
    <?php echo $row['Computer_&_Technology']; ?>, <?php echo $row['Active_Listening']; ?>, <?php echo $row['Creativity']; ?>,
    <?php echo $row['Leadership']; ?>, <?php echo $row['Problem_Solving']; ?>, <?php echo $row['Time_Management']; ?>, 
    <?php echo $row['Transferable']; ?>, <?php echo $row['Adaptability']; ?>, <?php echo $row['Empathy']; ?>, 
    <?php echo $row['Integrity']; ?>, <?php echo $row['Work_Ethic']; ?>],
    fill: true,
    backgroundColor: 'rgba(255, 99, 132, 0.2)',
    borderColor: 'rgb(255, 99, 132)',
    pointBackgroundColor: 'rgb(255, 99, 132)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgb(255, 99, 132)'
  }]
};


const config = {
  type: 'radar',
  data: data,
  options: {
    elements: {
      line: {
        borderWidth: 3
      }
    }
  },
};

var myChart = new Chart(
    document.getElementById('myChart'),
    config
  );

  myChart.canvas.parentNode.style.height = '500px';
  myChart.canvas.parentNode.style.width = '500px';
    </script>
    <section class="content">

<!-- Default box -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title">Soft Skills Detail</h3>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
      <table id="dataTable" class="table table-bordered table-striped">
          <thead>
          <tr class="text-center">
              <th>Topics</th>
              <th>Percentage</th>
              <th>Topics</th>
              <th>Percentage</th>

          </tr>
          </thead>
          <tbody>
          <?php for ($i=1; $i < 50 ; $i++) { 
            $num = 0;
            while($row = $result->fetch_assoc() ) { 
              $num++;?>
          <tr>
              <td>Communication</td>
              <td><?php echo $row['Communication'] ?></td>
              <td>Customer Service</td>
              <td><?php echo $row['Customer_Service'] ?></td>
          </tr>
          <?php } 
          }?>
          </tbody>
          <tfoot>
          <tr  class="text-center">
          <th>Topics</th>
              <th>Percentage</th>
              <th>Topics</th>
              <th>Percentage</th>
          </tr>
          </tfoot>
      </table>
  </div>
  <!-- /.card-body -->
</div>
<!-- /.card -->

</section>
  <script src="node_modules/jquery/dist/jquery.min.js"></script>
  <script src="node_modules/popper.js/dist/umd/popper.min.js"></script>
  <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
</body>
</html>
