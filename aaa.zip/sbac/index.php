<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<?php
if(@$_GET['page'] == 'index');
require_once('include/head.php');
?>
      <?php
    if(@$_GET['page'] == 'index');
    require_once('connect.php');
    ?>
<title>Index</title>
</head>
<body>
  <!--navbar-->
  <?php
if(@$_GET['page'] == 'index');
require_once('include/nav.php');
?>
  
<h3>สวัสดี คุณ <?php echo $row['name']?> <?php echo $row['surname']?> เข้าสู่เว็ปsbac ในรุปแบบของ .......</h3>


<!--/ navbar-->
<!-- slide -->
<div class="container ">
  <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="img/bg1.jpg" class="d-block w-100" alt="bg1">
        <div class="carousel-caption d-none d-md-block">
          <h5>First slide label</h5>
          <p>Some representative placeholder content for the first slide.</p>
        </div>
      </div>
      <div class="carousel-item">
        <img src="img/bg2.jpg" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
          <h5>Second slide label</h5>
          <p>Some representative placeholder content for the second slide.</p>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>
</div>
<H2></H2>


          <style>
          h3 {text-align: center;}
        </style>
        <div >
          <h3 >กิจกรรม</h3>
          <table class="table table-bordered table-striped myTable" style="width: 100% " >
          <thead>
            <tr class="text-center">
            <th>ลำดับที่</th>
              <th>วันที่ประกาศกิจกรรม</th>
              <th>หัวข้อกิจกรรม</th>
              <th>ผู้แจ้ง</th>
            </tr>
            </thead>
            <tbody>
           <?php $search=isset($_GET['search']) ? $_GET['search']: '';
    
    $sql = "SELECT * FROM event WHERE id_event LIKE '%".$search."%'"; 
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    ?>
              <?php 
            $num = 0;
            while($row = $result->fetch_assoc() ) { 
              $num++;
              ?>
            <tr class="text-center">
                  <td><?php echo $row["id_news"];?></td>
                  <td><?php echo $row["date"];?></td>
                  <td><a href="aa4.html"><?php echo $row["head"];?></a></td>                  
                  <td><?php echo $row["name"];?> <?php echo $row["surname"];?></td>
            </tr>
            <?php } ?>
          </tbody>
          <tfoot>
          <thead>
            <tr class="text-center">
            <th>ลำดับที่</th>
              <th>วันที่ประกาศกิจกรรม</th>
              <th>หัวข้อกิจกรรม</th>
              <th>ผู้แจ้ง</th>
            </tr>
            </tfood>
          </table>
            </div>
          </div>

          

          <div>
              <div >
                <div >
                    
                </div><!-- Service 2 end -->
              </div><!-- col end -->
          </div><!-- Content row 1 end -->
        </div><!-- Col end -->
        <style>
          h3 {text-align: center;}
        </style>
        <div>
          <h3>ข่าวสาร</h3>
            <table class="table table-bordered table-striped myTable" style="width: 100% " >
              <thead>
            <tr class="text-center">
            <th>ลำดับที่</th>
              <th>วันที่ประกาศข่าว</th>
              <th>หัวข้อข่าว</th>
              <th>ผู้แจ้ง</th>
            </tr>
            </thead>
           <tbody>
           <?php $search1=isset($_GET['search']) ? $_GET['search']: '';
    
    $sql1 = "SELECT * FROM news WHERE id_news LIKE '%".$search1."%'"; 
    $result1 = $conn->query($sql1);
    $row1 = $result1->fetch_assoc();
    ?>
              <?php 
            $num = 0;
            while($row1 = $result1->fetch_assoc() ) { 
              $num++;
              ?>
            <tr class="text-center">
                  <td><?php echo $row1["id_news"];?></td>
                  <td><?php echo $row1["date"];?></td>
                  <td><a href="aa4.html"><?php echo $row1["head"];?></a></td>                  
                  <td><?php echo $row1["name"];?> <?php echo $row1["surname"];?></td>
            </tr>
            <?php } ?>
          </tbody>
          <tfoot>
          <thead>
            <tr class="text-center">
            <th>ลำดับที่</th>
              <th>วันที่ประกาศข่าว</th>
              <th>หัวข้อข่าว</th>
              <th>ผู้แจ้ง</th>
            </tr>
            </tfood>
          </table>
          </div>
          </div>
                </div>
              </div>
          </div>
          <!--/ Accordion end -->
        
        </div><!-- Col end -->
    </div><!-- Row end -->
  </div><!-- Container end -->

    <!--/ Title row end -->
    
  <!--/ Container end -->
</section>
  <!-- / slide -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
    <script src="../../assets/js/vendor/popper.min.js"></script>
    <script src="../../dist/js/bootstrap.min.js"></script>

    <!-- Icons -->
    <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
    <script>
      feather.replace()
    </script>
  <script>
$(document).ready( function () {
    $('.myTable').DataTable();
} );
    </script>
  <?php
if(@$_GET['page'] == 'index');
require_once('include/scr.php');
?>
</body>
</html>