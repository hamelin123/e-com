<?php session_start();?>
<?php if(@$_GET['page'] == 'register');?>
<!DOCTYPE html>
<html lang="en">
<?php
if(@$_GET['page'] == 'register');
require_once('include/head.php');
?>
<title>Register</title>

</head>
<body>

<?php   

include('connect.php');

if(isset($_POST['submit'])){              
      
    $email = $_POST['email'];
    $checkemail = "SELECT * FROM admin_reg WHERE email = '$email' LIMIT 1" ;
    $check_query = mysqli_query($conn,$checkemail);
    $count_email = mysqli_num_rows($check_query);
   
    if($count_email > 0){
    
        echo "<script>alert('มีอีเมล์ผู้ใช้นี้อยู่แล้ว');</script>";
        echo "<meta http-equiv='refresh' content='0;URL=register_a.php'>";
        exit();
    }        
     
        
    $sql = "INSERT INTO `admin_reg` (`id_adminreg`, `name`, `surname`, `id_admin`, `email`, `department`, `major`, `phone`, `line`)
     VALUES (NULL, '".$_POST['name']."', '".$_POST['surname']."',
       '".$_POST['id_admin']."', '".$_POST['email']."', '".$_POST['department']."', '".$_POST['major']."',
       '".$_POST['phone']."',  '".$_POST['line']."');";
    

    $result = $conn->query($sql) or die($conn->$error);

    if($result){
        echo '<script> alert("Register Completed!!") </script>';
        header('Refresh:0; url=login_a.php');
    }else{
        echo 'NO';
    }

}


            ?>
<div class="container">
         <div class="row">
            <div class="col-md-8 mx-auto mt-5 ">
                <div class="card">
                    <form  method="POST" enctype="multipart/form-data">
                        <div class="card-header text-center">
                            REGISTER ON ACCOUNT
                        </div>
                        <div class="card-body">
                        <div class="form-group row">
                            <label for="firstname" class="col-sm-3 col-form-label">First Name</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="name" name="name" placeholder = "ชื่อจริง" required> 
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="lastname" class="col-sm-3 col-form-label">Last Name</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="lastname" name="lastname" placeholder = "นามสกุล" required> 
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="email" class="col-sm-3 col-form-label">Email</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="email" name="email" placeholder = "Email" required>
                                </div>
                            </div>
                            <div class="form-group row">
                            <label for="department" class="col-sm-3 col-form-label">Department</label>
                                <div class="col-sm-9">
                                    <input type="department" class="form-control" id="department" name="department" placeholder = "ภาควิชา" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="major" class="col-sm-3 col-form-label">Major</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="major" name="major" placeholder = "สาขาวิชา" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="email" class="col-sm-3 col-form-label">ID</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="id_admin" name="id_admin" placeholder = "เลขประจำตัว 5 หลัก" required>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="phone" class="col-sm-3 col-form-label">Phone</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="phone" name="phone" placeholder = "เบอร์มือถือ" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="line" class="col-sm-3 col-form-label">Line</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" id="line" name="line" placeholder = "Line" required>
                                </div>
                            </div>
                            <div class="card-footer text-center">
                                    <input type="submit" name="submit" class="btn btn-info" value="Register">
                            </div>
                        </div>
                    </form>

                </div>
            </div>  
         </div> 
      </div>
      <?php
if(@$_GET['page'] == 'register');
require_once('include/scr.php');
?>
</body>
</html>