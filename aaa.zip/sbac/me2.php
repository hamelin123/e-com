<?php session_start();?>

<!DOCTYPE html>
<html lang="en">
<?php
if(@$_GET['page'] == 'me2');
require_once('include/head.php');
require_once('connect.php');
?>
    <title>Me2</title>
</head>
<body>
<?php
if(@$_GET['page'] == 'me2');
require_once('include/nav.php');
?>
<?php
    include('connect.php');
    if(isset($_POST['submit'])){

        $sql = "INSERT INTO `detail_stu` (`id_dstu`, `head`, `article`, `search`, `status`)
         VALUES (NULL, '".$_POST['head']."', '".$_POST['article']."', '".$_POST['search']."', '".$_POST['status']."');";

$result = $conn->query($sql) or die($conn->$error);
           if($result){
                echo '<script> alert("ส่งข้อมูลสำเร็จ") </script>';
                header('Refresh:0; url=me.php');
            }else{
                echo 'NO';
            }

        }
    ?>
<div class="container">
         <div class="row">
            <div class="col-md-8 mx-auto mt-5 ">
                <div class="card">
                    <form  method="POST" enctype="multipart/form-data">
                        <div class="card-header text-center">
                        สร้างบทความใหม่
                        </div>
                        <div class="card-body">
                <span class="input-group-text" id="inputGroup-sizing-default">หัวข้อบทความ</span>
                <input type="head" class="form-control" id="head" name="head" placeholder="หัวข้อบทความ" required>
            </div>
            <div class="card-body">
                <div class="mb-3">
                <textarea type="article" name="article" id="editor1" rows="10" cols="80">
                เขียนบทความที่ต้องการ
                </textarea>
            </div>
        </div>
        <div class="form-group">
              <label for="category">ประเภทบทความ</label>
              <select class="form-control" name="category" id="dd" required>
              <option value=""disabled selected>เลือกประเภท</option>
              <option value="1">1</option>
                <option value="2">2</option>
                  <option value="3">3</option>
              </select>
        </div>
        <div class="form-group">
              <label for="status">สถานะบทความ</label>
              <select class="form-control" name="status" id="ddd" required>
              <option value=""disabled selected>เลือกประเภท</option>
              <option value="1">1</option>
                <option value="2">2</option>
                  <option value="3">3</option>
              </select>
        </div>
        <div class="card-footer text-center">
              <input type="submit" name="submit" class="btn btn-primary center" value="submit">
              </div>
            </div>
                        </div>
                    </form>

                </div>
            </div>  
         </div> 
      </div>
      <?php
if(@$_GET['page'] == 'me2');
require_once('include/scr.php');
?>
    <script>
         $(document).ready(function(){
            $('.dropdown-toggle').dropdown()
        });
    </script>
<!-- CKEditer -->
<script src="//cdn.ckeditor.com/4.16.1/full/ckeditor.js"></script>
<script> CKEDITOR.replace( 'editor1' );</script>
<!-- END CKEditer -->
</body>
</html>