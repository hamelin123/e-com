<?php 

    $conn = new mysqli('127.0.0.1','root','123456789','sbac');

    $conn->set_charset('utf8');
    if ($conn->connect_errno){
        echo "Connect Error :".$conn->connect_error;
        exit(); 

    }
    ?>