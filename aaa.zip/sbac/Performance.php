<?php session_start();?>
<?php
/*
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
*/

    include 'connect.php';

    $sql = 'SELECT * FROM `radar` ';
    $result = mysqli_query($conn,$sql);
    
    $row = mysqli_fetch_array($result,MYSQLI_BOTH);



    //mysqli_query($conn);

    //echo json_encode($radar);


    ?>

<?php if(@$_GET['page'] == 'Performance');?>
<!DOCTYPE html>
<html lang="en">
<?php
if(@$_GET['page'] == 'performance');
require_once('include/head.php');
?>
<title>Performance</title>

</head>
<body>
<?php
if(@$_GET['page'] == 'performance');
require_once('include/nav.php');
?>
<center>
<div>
  <canvas id="myChart" width="400" height="400"></canvas>
</div>
</center>

<script>
    
    var data = {
  labels: [
    'Communication',
    'Customer Service',
    'Interpersonal',
    'Computer & Technology',
    'Active Listening',
    'Creativity',
    'Leadership',
    'Problem Solving',
    'Time Management',
    'Transferable',
    'Adaptability',
    'Empathy',
    'Integrity',
    'Work Ethic'
  ],
  datasets: [{
    label: 'Soft Skills',
    data: [<?php echo $row['Communication']; ?>, <?php echo $row['Customer_Service']; ?>, <?php echo $row['Interpersonal']; ?>,
    <?php echo $row['Computer_&_Technology']; ?>, <?php echo $row['Active_Listening']; ?>, <?php echo $row['Creativity']; ?>,
    <?php echo $row['Leadership']; ?>, <?php echo $row['Problem_Solving']; ?>, <?php echo $row['Time_Management']; ?>, 
    <?php echo $row['Transferable']; ?>, <?php echo $row['Adaptability']; ?>, <?php echo $row['Empathy']; ?>, 
    <?php echo $row['Integrity']; ?>, <?php echo $row['Work_Ethic']; ?>],
    fill: true,
    backgroundColor: 'rgba(255, 99, 132, 0.2)',
    borderColor: 'rgb(255, 99, 132)',
    pointBackgroundColor: 'rgb(255, 99, 132)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgb(255, 99, 132)'
  }]
};


var config = {
  type: 'radar',
  data: data,
  options: {
    elements: {
      line: {
        borderWidth: 3
      }
    }
  },
};

var myChart = new Chart(
    document.getElementById('myChart'),
    config
  );

  myChart.canvas.parentNode.style.height = '500px';
  myChart.canvas.parentNode.style.width = '500px';
    </script>
    <div class="container">
    <section class="content">
<br>
<!-- Default box -->

<div class="card">
  <div class="card-header">
    <h3 class="card-title text-center">Soft Skills Detail</h3>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
      <table id="dataTable" class="table table-bordered table-striped">
          <thead>
          <tr class="text-center">
              <th>Topics</th>
              <th>Percentage</th>
              <th>Topics</th>
              <th>Percentage</th>

          </tr>
          </thead>
          <tbody>
          <tr class="text-center">
              <td>Communication</td>
              <td><?php echo $row['Communication'] ?></td>
              <td>Customer Service</td>
              <td><?php echo $row['Customer_Service'] ?></td>
          </tr>
          </tbody>

          <tbody>
          <tr class="text-center">
              <td>Interpersonal</td>
              <td><?php echo $row['Interpersonal'] ?></td>
              <td>Computer & Technology</td>
              <td><?php echo $row['Computer_&_Technology'] ?></td>
          </tbody>

          <tbody>
          <tr class="text-center">
              <td>Active Listening</td>
              <td><?php echo $row['Active_Listening'] ?></td>
              <td>Creativity</td>
              <td><?php echo $row['Creativity'] ?></td>
          </tbody>

          <tbody>
          <tr class="text-center">
              <td>Leadership</td>
              <td><?php echo $row['Leadership'] ?></td>
              <td>Problem Solving</td>
              <td><?php echo $row['Problem_Solving'] ?></td>
          </tbody>

          <tbody>
          <tr class="text-center">
              <td>Time Management</td>
              <td><?php echo $row['Time_Management'] ?></td>
              <td>Transferable</td>
              <td><?php echo $row['Transferable'] ?></td>
          </tbody>

          <tbody>
          <tr class="text-center">
              <td>Adaptability</td>
              <td><?php echo $row['Adaptability'] ?></td>
              <td>Empathy</td>
              <td><?php echo $row['Empathy'] ?></td>
          </tbody>

          <tbody>
          <tr class="text-center">
              <td>Integrity</td>
              <td><?php echo $row['Integrity'] ?></td>
              <td>Work Ethic</td>
              <td><?php echo $row['Work_Ethic'] ?></td>
          </tbody>

          <tfoot>
          <tr class="text-center">
              <th>Topics</th>
              <th>Percentage</th>
              <th>Topics</th>
              <th>Percentage</th>

          </tr>
          </tfoot>
      </table>
  </div>
  <!-- /.card-body -->
</div>
<!-- /.card -->


</section>
</div>
<br>
<?php  
    $sql1 = 'SELECT * FROM `pie` ';
    $result1 = mysqli_query($conn,$sql1);
    
    
    $row1 = mysqli_fetch_array($result1,MYSQLI_BOTH);?>

<center>
<div>
  <canvas id="myChart1" width="400" height="400"></canvas>
</div>
</center>




<script>

var data = {
  labels: [
    ' สมรรถนะแกนกลาง',
    ' สมรรถนะวิชาชีพ',
    ' เลือกเสรี',
    ' กิจกรรมเสริมหลักสูตร'
  ],
  datasets: [{
    label: 'Hard Skills',
    data: [<?php echo $row1['core_performance']; ?>, <?php echo $row1['professional_competence']; ?>, <?php echo $row1['free_choice']; ?>,
    <?php echo $row1['extracurricular_activities']; ?>],
    backgroundColor: [
      'rgb(255, 99, 132)',
      'rgb(75, 192, 192)',
      'rgb(255, 205, 86)',
      'rgb(201, 203, 207)'
    ]
  }]
};

var config = {
  type: 'pie',
  data: data,
};
  
var myChart1 = new Chart(
    document.getElementById('myChart1'),
    config
  );

  myChart1.canvas.parentNode.style.height = '500px';
  myChart1.canvas.parentNode.style.width = '500px';
</script>

<center>
<div>
  <canvas id="myChart2" width="400" height="400"></canvas>
</div>
</center>


<script>

const DATA_COUNT = 7;
const NUMBER_CFG = {count: DATA_COUNT, max: 100};

const labels = Utils.months({count: 7});
const data = {
  labels: labels,
  datasets: [
    {
      label: 'Dataset 1',
      data: Utils.numbers(NUMBER_CFG),
      backgroundColor: Utils.CHART_COLORS.red,
    },
    {
      label: 'Dataset 2',
      data: Utils.numbers(NUMBER_CFG),
      backgroundColor: Utils.CHART_COLORS.blue,
    },
    {
      label: 'Dataset 3',
      data: Utils.numbers(NUMBER_CFG),
      backgroundColor: Utils.CHART_COLORS.green,
    },
  ]
};

const actions = [
  {
    name: 'Randomize',
    handler(chart) {
      chart.data.datasets.forEach(dataset => {
        dataset.data = Utils.numbers({count: chart.data.labels.length, min: -100, max: 100});
      });
      chart.update();
    }
  },
];

const config = {
  type: 'bar',
  data: data,
  options: {
    plugins: {
      title: {
        display: true,
        text: 'Chart.js Bar Chart - Stacked'
      },
    },
    responsive: true,
    scales: {
      x: {
        stacked: true,
      },
      y: {
        stacked: true
      }
    }
  }
};

var myChart2 = new Chart(
    document.getElementById('myChart2'),
    config
  );

  myChart2.canvas.parentNode.style.height = '500px';
  myChart2.canvas.parentNode.style.width = '500px';


</script>

<?php
if(@$_GET['page'] == 'performance');
require_once('include/scr.php');
?>
</body>
</html>
