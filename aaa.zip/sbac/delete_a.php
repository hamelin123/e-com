
<?php

session_start();
require_once('connect.php');
?>
<?php
    $id = $_GET['id_stu'];
    if (isset($id) && $id != 1 ){
        $sql = "DELETE FROM `student` WHERE `student`.`id_stu` = '".$id."'";
        $result = $conn->query($sql);

        if ($conn->affected_rows){
    echo '<script> alert("Finished Deleting!")</script>'; 
    header('Refresh:0; url=index_a.php');
        }else{
        echo '<script> alert("No Data!")</script>'; 
        header('Refresh:0; url=index_a.php');
    }
} else {
    header('Refresh:0; url=index_a.php');
}
?>