<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<?php
if(@$_GET['page'] == 'me');
require_once('include/head.php');
require_once('connect.php');
?>
    <title>Me</title>
</head>
<body>
<?php
if(@$_GET['page'] == 'me');
require_once('include/nav.php');
?>
<h1>บทความของฉัน</h1>

<form class="form-inline my-2 my-lg-0">
    <form method="GET" action="me2.php">
    <div class="container md-3">
        <a class="p1 btn btn-primary md-3" style="float: right;" href="me2.php"> <img src="img/paper.png" alt="Smiley face" width="15" height="15">สร้างบทความใหม่</a>
    </form>
  </form>
  <table class="table table-bordered myTable" style="width: 100% ">
    <thead>
      <tr>
        <th scope="col">ลําดับ</th>
        <th scope="col">ว-ด-ป ที่เขียน</th>
        <th scope="col">ชื่อบทความ</th>
        <th scope="col">ประเภทบทความ</th>
        <th scope="col">สถานะบทความ</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
    <?php $search=isset($_GET['search']) ? $_GET['search']: '';
    
    $sql = "SELECT * FROM detail_stu WHERE id_dstu LIKE '%".$search."%'"; 
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    ?>
              <?php 
            $num = 0;
            while($row = $result->fetch_assoc() ) { 
              $num++;
              ?>
               <tr>
                  <td><?php echo $row["id_dstu"];?></td>
                  <td><?php echo $row["head"];?></td>
                  <td><?php echo $row["article"];?></td>
                  <td><?php echo $row["search"];?></td>
                  <td><?php echo $row["status"];?></td>
                  <td>
                  <a href="view.php?id_stu=<?php echo $row['id_stu']; ?>" class="btn btn-sm btn-warning text-white mx-2">
                  <span data-feather="file"></span> view <a href="edit_a.php?id_stu=<?php echo $row['id_stu']; ?>" class="btn btn-sm btn-warning text-white mx-2">
                  <span data-feather="edit"></span> edit <a href="delete_a.php?id_stu=<?php echo $row['id_stu']; ?>" onclick="deleteItem(<?php echo $row['id_stu']; ?>);" class="btn btn-sm btn-danger">  
                  <span data-feather="delete"></span> Delete
                  </a> 
                  </a> 

                  <?php } ?>
            </tr>
    </tbody>
    <tfood>
    <th scope="col">ลําดับ</th>
        <th scope="col">ว-ด-ป ที่เขียน</th>
        <th scope="col">ชื่อบทความ</th>
        <th scope="col">ประเภทบทความ</th>
        <th scope="col">สถานะบทความ</th>
        <th scope="col">Action</th>
            </tfood>
  </table>
</div>
<?php
if(@$_GET['page'] == 'me');
require_once('include/scr1.php');
?>

<script>
$(document).ready( function () {
    $('.myTable').DataTable();
} );
    </script>
<?php
if(@$_GET['page'] == 'me');
require_once('include/scr.php');
?>
</body>
</html>